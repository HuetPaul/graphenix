# -*- coding: utf-8 -*-

from __future__ import annotations

#from unittest.mock import right
from illuspy.objet import *
from illuspy.gui import plot

