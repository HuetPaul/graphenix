# -*- coding: utf-8 -*-

from __future__ import annotations

#from unittest.mock import right
from graphenix.objet import *
from graphenix.gui import plot

