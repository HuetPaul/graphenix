# -*- coding: utf-8 -*-

from __future__ import annotations

#from unittest.mock import right
from graphiques.objet import *
from graphiques.gui import plot

